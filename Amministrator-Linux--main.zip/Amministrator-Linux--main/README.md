# Amministrazione Linux

Benvenuti nella repository **Amministrazione Linux**!  
Questa raccolta contiene vari script e comandi per l'amministrazione di sistemi Linux, inclusi esempi di configurazione di Apache, Tomcat, Java, Maven e gestione di MySQL e Termux.

## 📂 Struttura dei file

- **AmministratorMysql.sql**: Script per la gestione di MySQL.
- **Apache.txt**: Comandi per la configurazione di Apache.
- **Cancellare cronologia Shell Linux o Termux**: Istruzioni per cancellare la cronologia della shell.
- **ComandiTermux.txt**: Comandi utili per l'utilizzo di Termux.
- **FormattaDiskUsbLinux.txt**: Istruzioni per formattare un disco USB in Linux.
- **InstallTomcat.sh**: Script per l'installazione di Tomcat.
- **InstallazioneJavaLinux**: Istruzioni per l'installazione di Java su Linux.
- **InstalliazioneApacheLinixMin**: Istruzioni per l'installazione di Apache su Linux Mint.
- **Linux.txt**: Comandi generali per Linux.
- **LinuxMaven**: Istruzioni per l'installazione di Maven su Linux.
- **Linux_partizionemento.txt**: Istruzioni per il partizionamento del disco in Linux.
- **MariadbTermux.txt**: Istruzioni per l'installazione di MariaDB su Termux.
- **Maven**: Istruzioni per l'installazione di Maven.
- **MysqlAmministrator.txt**: Comandi per la gestione di MySQL.
- **Partizioni .txt**: Istruzioni per la gestione delle partizioni.
- **Permessi linux esercizi .txt**: Esercizi sui permessi in Linux.
- **ServerWebTermux.txt**: Istruzioni per la configurazione di un server web su Termux.

## ⚙️ Tecnologie utilizzate

- Linux
- Apache
- Tomcat
- Java
- Maven
- MySQL
- Termux

## 📄 Licenza

Questa repository è condivisa a scopo educativo e personale. Per usi commerciali contattare l’autore.

## 👤 Autore

**SalvoNet** – Tecnico in elettronica appassionato di amministrazione di sistemi Linux.
