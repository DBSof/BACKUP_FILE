# AWS_corso_ForteChange

AWS (Amazon Web Services) è una piattaforma di cloud computing che offre una vasta gamma di servizi, inclusi calcolo, archiviazione, database, machine learning, networking, analytics, e sicurezza, per supportare le aziende nella gestione delle loro infrastrutture IT. AWS permette alle aziende di ridurre i costi operativi e di scalare facilmente le risorse in base alle necessità, migliorando la flessibilità e l'affidabilità dei servizi.

 Ho frequentato un corso di AWS con Fortechange, dove ha approfondito l'uso dei principali servizi della piattaforma, imparando a gestire risorse nel cloud, configurare istanze, gestire la sicurezza e l'archiviazione, e automatizzare i processi tramite i comandi AWS. Il corso ha fornito competenze pratiche per l'implementazione di soluzioni scalabili e sicure nel cloud.

 # AWS Corso ForteChange

Benvenuti nella repository **AWS Corso ForteChange**!  
Questa raccolta contiene script, comandi e appunti relativi all’uso di AWS e alla gestione di sistemi Linux collegati ad AWS, sviluppati durante il corso.

## 📂 Struttura dei file

### 1. Backup e ripristino
- Script per backup e ripristino di risorse AWS.

### 2. Comandi amministrativi
- File di testo con comandi per la gestione di MySQL, Apache, Tomcat, Java e Maven su sistemi Linux collegati ad AWS.

### 3. Sicurezza
- Script e comandi per configurare la sicurezza dei server.

### 4. Appunti e guide
- File PDF o TXT contenenti note di corso e guide pratiche.

## ⚙️ Tecnologie utilizzate
- AWS (EC2, S3, RDS)
- Linux
- MySQL
- Apache
- Tomcat
- Java
- Maven

## 📄 Licenza
Questa repository è condivisa a scopo educativo e personale. Per usi commerciali contattare l’autore.

## 👤 Autore
**SalvoNet** – Tecnico in elettronica appassionato di Cloud Computing e AWS.

